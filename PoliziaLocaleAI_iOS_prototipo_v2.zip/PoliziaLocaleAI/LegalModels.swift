import SwiftUI

enum LegalArea: String, CaseIterable, Hashable {
    case cds = "Codice della Strada"
    case penale = "Codice Penale"
    case ambiente = "Ambiente"
    case edilizia = "Edilizia"

    var shortName: String {
        switch self {
        case .cds: "CDS"
        case .penale: "Penale"
        case .ambiente: "Ambiente"
        case .edilizia: "Edilizia"
        }
    }

    var icon: String {
        switch self {
        case .cds: "car.fill"
        case .penale: "building.columns.fill"
        case .ambiente: "leaf.fill"
        case .edilizia: "hammer.fill"
        }
    }

    var tint: Color {
        switch self {
        case .cds: .blue
        case .penale: .purple
        case .ambiente: .green
        case .edilizia: .orange
        }
    }

    var description: String {
        switch self {
        case .cds: "Circolazione, sanzioni, documenti e procedure."
        case .penale: "Fattispecie, elementi e attività di PG."
        case .ambiente: "Rifiuti, scarichi, emissioni e controlli."
        case .edilizia: "Titoli, abusi, ordinanze e accertamenti."
        }
    }

    var prompt: String {
        switch self {
        case .cds: "Qual è la disciplina applicabile in questo caso secondo il Codice della Strada?"
        case .penale: "Quale fattispecie penale può essere rilevante in questo caso?"
        case .ambiente: "Quali norme ambientali e quali adempimenti devo verificare?"
        case .edilizia: "Quali verifiche edilizie devo effettuare e quali norme devo considerare?"
        }
    }
}

struct OperationalNote: Identifiable {
    let id = UUID()
    let title: String
    let steps: [String]
    let caution: String
}

struct LegalAnswer {
    let area: LegalArea
    let title: String
    let explanation: String
    let references: [String]
    let warning: String
    let confidence: String
    let operationalNotes: [OperationalNote]
}

enum LegalKnowledge {
    static let quickQuestions = [
        "Quali documenti devo controllare durante un posto di controllo?",
        "Come distinguere un illecito amministrativo da un reato?",
        "Quali verifiche fare su un abbandono di rifiuti?",
        "Cosa controllare in un intervento per presunto abuso edilizio?"
    ]

    static func answer(for question: String, area: LegalArea?) -> LegalAnswer {
        let q = question.lowercased()

        if q.contains("rifiut") || area == .ambiente {
            return LegalAnswer(
                area: .ambiente,
                title: "Verifica ambientale: rifiuti",
                explanation: "Individua anzitutto la condotta concreta, la tipologia di rifiuto, il luogo, il soggetto responsabile e le eventuali autorizzazioni. La risposta operativa deve poi essere verificata sulla disciplina vigente e sulle competenze dell'ente.",
                references: ["D.Lgs. 152/2006 — Parte IV", "Normativa regionale applicabile", "Eventuali regolamenti comunali"],
                warning: "La qualificazione dell'illecito dipende dai fatti accertati e dalla normativa vigente al momento del fatto.",
                confidence: "DA VERIFICARE",
                operationalNotes: LegalKnowledge.notes(for: .ambiente)
            )
        }

        if q.contains("edil") || q.contains("abuso") || area == .edilizia {
            return LegalAnswer(
                area: .edilizia,
                title: "Accertamento edilizio",
                explanation: "Per un sopralluogo occorre ricostruire lo stato dei luoghi, acquisire gli atti edilizi disponibili, confrontare opere e titoli e documentare eventuali difformità. La qualificazione giuridica va effettuata sulla disciplina vigente e sugli atti comunali.",
                references: ["D.P.R. 380/2001", "Strumenti urbanistici comunali", "Normativa regionale vigente"],
                warning: "Non utilizzare una risposta generica per qualificare un abuso: verificare sempre titolo, epoca dell'intervento, zona urbanistica e disciplina regionale.",
                confidence: "DA VERIFICARE",
                operationalNotes: LegalKnowledge.notes(for: .edilizia)
            )
        }

        if q.contains("reato") || q.contains("penal") || area == .penale {
            return LegalAnswer(
                area: .penale,
                title: "Valutazione della fattispecie penale",
                explanation: "Parti dai fatti oggettivamente accertati: condotta, soggetto, elemento soggettivo richiesto, eventuale evento, circostanze e procedibilità. Solo dopo collega i fatti alla fattispecie prevista dalla legge.",
                references: ["Codice Penale", "Codice di Procedura Penale", "Norme speciali applicabili"],
                warning: "La schermata non sostituisce la verifica dell'articolo vigente, della giurisprudenza pertinente e delle direttive dell'autorità giudiziaria.",
                confidence: "DA VERIFICARE",
                operationalNotes: LegalKnowledge.notes(for: .penale)
            )
        }

        return LegalAnswer(
            area: .cds,
            title: "Verifica secondo il Codice della Strada",
            explanation: "Descrivi con precisione la condotta, il veicolo, il luogo, la segnaletica, i documenti esibiti e ogni circostanza rilevante. L'assistente deve poi collegare i fatti alla disposizione vigente e indicare sanzione, eventuali sanzioni accessorie e procedura.",
            references: ["D.Lgs. 285/1992 — Codice della Strada", "D.P.R. 495/1992 — Regolamento di esecuzione", "Normativa vigente e circolari applicabili"],
            warning: "Prima di contestare o adottare provvedimenti verifica sempre il testo vigente della norma e gli eventuali aggiornamenti.",
            confidence: "DA VERIFICARE",
            operationalNotes: LegalKnowledge.notes(for: .cds)
        )
    }

    static func notes(for area: LegalArea) -> [OperationalNote] {
        var notes: [OperationalNote] = []

        notes.append(OperationalNote(
            title: "Nota operativa: documentazione",
            steps: [
                "Identificare con precisione il fatto, data, ora, luogo e soggetti coinvolti.",
                "Acquisire e conservare gli atti, documenti e immagini pertinenti secondo le procedure dell'ente.",
                "Indicare nella relazione le verifiche eseguite, le fonti consultate e gli eventuali esiti.",
                "Verificare sempre competenza dell'ufficio e modulistica/procedure interne vigenti."
            ],
            caution: "Le modalità concrete di protocollazione, conservazione e firma possono essere stabilite dall'ente e dai sistemi documentali utilizzati."
        ))

        notes.append(OperationalNote(
            title: "Nota operativa: invio tramite PEC",
            steps: [
                "Verificare l'indirizzo PEC ufficiale del destinatario su una fonte istituzionale o nell'elenco utilizzato dall'ente.",
                "Preparare l'atto nel formato richiesto, verificando firma digitale, allegati, denominazione dei file e leggibilità.",
                "Controllare che il messaggio PEC indichi chiaramente mittente, destinatario, oggetto, procedimento e riferimento dell'atto.",
                "Allegare esclusivamente la documentazione necessaria, applicando le regole interne sulla riservatezza e sulla protezione dei dati.",
                "Inviare dalla casella istituzionale autorizzata.",
                "Conservare ricevuta di accettazione e ricevuta di avvenuta consegna insieme alla documentazione del procedimento.",
                "Registrare nel fascicolo/protocollo gli estremi dell'invio secondo le procedure dell'ente."
            ],
            caution: "Non usare indirizzi PEC reperiti da fonti non ufficiali. Verificare sempre eventuali prescrizioni specifiche del destinatario e del sistema documentale dell'ente."
        ))

        notes.append(OperationalNote(
            title: "Nota operativa: trasmissione atti alla Procura",
            steps: [
                "Verificare se si tratta di una comunicazione/notizia di reato, di un atto da trasmettere o di altra comunicazione richiesta dall'autorità giudiziaria.",
                "Predisporre la relazione/annotazione di PG e gli atti allegati secondo le forme previste dal procedimento.",
                "Numerare o identificare gli allegati e predisporre un indice della documentazione trasmessa.",
                "Indicare gli estremi essenziali del procedimento, il fatto, i soggetti interessati e le attività compiute, evitando valutazioni non necessarie.",
                "Verificare la Procura competente e il canale di trasmissione prescritto: PEC istituzionale, portale o altro sistema indicato dall'ufficio.",
                "Applicare le regole interne per firma digitale, protocollazione, riservatezza e conservazione.",
                "Conservare prova della trasmissione e inserirla nel fascicolo secondo le procedure dell'ufficio."
            ],
            caution: "La modalità di trasmissione degli atti può variare in base alla Procura, al tipo di atto e ai sistemi telematici vigenti. Prima dell'invio verificare le disposizioni della Procura competente e le direttive del proprio comando."
        ))

        return notes
    }

}
