import SwiftUI

struct ContentView: View {
    @State private var question = ""
    @State private var selectedArea: LegalArea? = nil
    @State private var answer: LegalAnswer? = nil
    @State private var showingSources = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header

                    searchBox

                    if let answer {
                        AnswerCard(answer: answer, showingSources: $showingSources)
                    } else {
                        areaGrid
                        quickQuestions
                    }
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Polizia Locale AI")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Assistente operativo")
                .font(.largeTitle.bold())
            Text("Cerca norme e procedure per l’attività di polizia locale.")
                .foregroundStyle(.secondary)
        }
    }

    private var searchBox: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                TextField("Es. “Quale sanzione per…?”", text: $question, axis: .vertical)
                    .textFieldStyle(.plain)
                    .lineLimit(1...4)
                if !question.isEmpty {
                    Button { question = ""; answer = nil } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                    }
                }
            }
            .padding(14)
            .background(.background, in: RoundedRectangle(cornerRadius: 16))

            HStack {
                ForEach(LegalArea.allCases, id: \.self) { area in
                    Button(area.shortName) {
                        selectedArea = area
                        question = area.prompt
                        answer = LegalKnowledge.answer(for: question, area: area)
                    }
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(area.tint.opacity(0.12), in: Capsule())
                    .foregroundStyle(area.tint)
                }
            }

            Button {
                answer = LegalKnowledge.answer(for: question, area: selectedArea)
            } label: {
                Label("Cerca nella banca normativa", systemImage: "arrow.right.circle.fill")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
            }
            .buttonStyle(.borderedProminent)
            .disabled(question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
    }

    private var areaGrid: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Aree operative").font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(LegalArea.allCases, id: \.self) { area in
                    Button {
                        selectedArea = area
                        question = area.prompt
                        answer = LegalKnowledge.answer(for: question, area: area)
                    } label: {
                        VStack(alignment: .leading, spacing: 9) {
                            Image(systemName: area.icon).font(.title2)
                            Text(area.rawValue).font(.headline)
                            Text(area.description).font(.caption).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, minHeight: 110, alignment: .leading)
                        .padding(14)
                        .background(.background, in: RoundedRectangle(cornerRadius: 18))
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.primary)
                }
            }
        }
    }

    private var quickQuestions: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Domande frequenti").font(.headline)
            ForEach(LegalKnowledge.quickQuestions, id: \.self) { q in
                Button {
                    question = q
                    answer = LegalKnowledge.answer(for: q, area: nil)
                } label: {
                    HStack {
                        Text(q).multilineTextAlignment(.leading)
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(14)
                    .background(.background, in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
                .foregroundStyle(.primary)
            }
        }
    }
}

struct AnswerCard: View {
    let answer: LegalAnswer
    @Binding var showingSources: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Label(answer.area.rawValue, systemImage: answer.area.icon)
                    .font(.subheadline.bold())
                Spacer()
                Text(answer.confidence)
                    .font(.caption.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(Color.green.opacity(0.12), in: Capsule())
                    .foregroundStyle(.green)
            }

            Text(answer.title).font(.title3.bold())
            Text(answer.explanation).font(.body)

            VStack(alignment: .leading, spacing: 8) {
                Text("Riferimenti").font(.headline)
                ForEach(answer.references, id: \.self) { ref in
                    Label(ref, systemImage: "doc.text")
                        .font(.subheadline)
                }
            }

            Divider()

            Text("Attenzione operativa")
                .font(.headline)
            Text(answer.warning)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 12) {
                Text("Note operative")
                    .font(.headline)

                ForEach(answer.operationalNotes) { note in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(note.title)
                            .font(.subheadline.bold())

                        ForEach(Array(note.steps.enumerated()), id: \.offset) { index, step in
                            HStack(alignment: .top, spacing: 8) {
                                Text("\(index + 1)")
                                    .font(.caption.bold())
                                    .frame(width: 22, height: 22)
                                    .background(Color.accentColor.opacity(0.12), in: Circle())
                                Text(step)
                                    .font(.subheadline)
                            }
                        }

                        Text("⚠︎ " + note.caution)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 14))
                }
            }

            Button {
                showingSources = true
            } label: {
                Label("Vedi fonti e versione normativa", systemImage: "link")
            }
            .sheet(isPresented: $showingSources) {
                SourceSheet(answer: answer)
                    .presentationDetents([.medium, .large])
            }
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 20))
    }
}

struct SourceSheet: View {
    let answer: LegalAnswer
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Fonti") {
                    ForEach(answer.references, id: \.self) { ref in
                        Text(ref)
                    }
                }
                Section("Aggiornamento") {
                    Text("Questa schermata è un prototipo. In produzione ogni risposta deve essere collegata a una fonte ufficiale, con data/versione e storico delle modifiche.")
                }
            }
            .navigationTitle("Fonti")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Chiudi") { dismiss() }
                }
            }
        }
    }
}
