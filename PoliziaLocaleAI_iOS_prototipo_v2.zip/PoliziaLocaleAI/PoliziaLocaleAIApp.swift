import SwiftUI

@main
struct PoliziaLocaleAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
